const form = document.getElementById("loginForm")
const nomeInput = document.getElementById("nome")
const crmInput = document.getElementById("crm")
const errorMessage = document.getElementById("errorMessage")
const submitButton = document.getElementById("submitButton")

// Convert Nome to title case
nomeInput.addEventListener("input", (e) => {
  e.target.value = e.target.value.replace(/\b\w/g, l => l.toUpperCase())
})

// Convert CRM to uppercase
crmInput.addEventListener("input", (e) => {
  e.target.value = e.target.value.toUpperCase()
})

// Form submission
form.addEventListener("submit", async (e) => {
  e.preventDefault()

  // Reset error message
  errorMessage.style.display = "none"
  errorMessage.textContent = ""

  // Disable button and show loading state
  submitButton.disabled = true
  const originalText = submitButton.textContent
  submitButton.textContent = "Entrando..."

  // Validate fields
  const nome = nomeInput.value.trim()
  const crm = crmInput.value.trim()

  if (!nome || !crm) {
    showError("Por favor, preencha todos os campos")
    resetButton()
    return
  }

  // Validate Nome (minimum 2 characters)
  if (nome.length < 2) {
    showError("Nome deve ter pelo menos 2 caracteres")
    resetButton()
    return
  }

  // Validate CRM (minimum 4 characters)
  if (crm.length < 4) {
    showError("CRM inválido")
    resetButton()
    return
  }

  try {
    const response = await fetch('http://localhost:3000/api/medicos/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome, crm })
    });

    const data = await response.json();

    if (response.ok) {
      console.log("[v1] Login successful:", data.medico)
      // Redirect to the medicos list page
      window.location.href = 'admin/medicos/lista.html'
    } else {
      showError(data.error || "Erro ao fazer login")
    }
  } catch (error) {
    console.error("[v1] Login error:", error)
    showError("Erro ao fazer login. Tente novamente.")
  } finally {
    resetButton()
  }

  function resetButton() {
    submitButton.disabled = false
    submitButton.textContent = originalText
  }
})

function showError(message) {
  errorMessage.textContent = message
  errorMessage.style.display = "block"
}
