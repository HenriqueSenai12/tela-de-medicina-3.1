let pieChart, lineChart, barChart;

/* ============================
   BUSCA DADOS DO BACKEND REAL
   ============================ */
async function fetchConsultasData() {
  const res = await fetch("http://localhost:3000/api/consultas");
  if (!res.ok) throw new Error("Erro ao buscar consultas");
  return await res.json();
}

async function fetchConcluidasData() {
  const res = await fetch("http://localhost:3000/api/concluida");
  if (!res.ok) throw new Error("Erro ao buscar consultas concluídas");
  return await res.json();
}

async function fetchMedicosData() {
  const res = await fetch("http://localhost:3000/api/medicos");
  if (!res.ok) throw new Error("Erro ao buscar médicos");
  return await res.json();
}

/* ===================================
   CONFIGURAÇÕES DOS GRÁFICOS
   =================================== */
function formatDate(dateStr) {
  const [year, month, day] = dateStr.split('-');
  return `${day}/${month}/${year.slice(-2)}`;
}

function getAggregationKey(dateStr, timeStr, aggregation) {
  // Parse date if it's ISO string
  const date = new Date(dateStr);
  const year = date.getFullYear().toString();
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const day = date.getDate().toString().padStart(2, '0');
  const hour = timeStr.split(':')[0];
  switch (aggregation) {
    case 'day':
      return `${year}-${month}-${day}`;
    case 'month':
      return `${year}-${month}`;
    case 'year':
      return year;
    case 'hour':
      return hour;
    default:
      return `${year}-${month}-${day}`;
  }
}

function formatLabel(key, aggregation) {
  switch (aggregation) {
    case 'day':
      return formatDate(key);
    case 'month':
      const [year, month] = key.split('-');
      return `${month}/${year}`;
    case 'year':
      return key;
    case 'hour':
      return `${key}:00`;
    default:
      return formatDate(key);
  }
}
const lineConfig = [
  {
    label: "Consultas Totais",
    data: [],
    borderColor: "#fae206",
    backgroundColor: "rgba(250, 226, 6, 0.12)",
    fill: true,
    tension: 0.3,
    borderWidth: 5,
    pointRadius: 10,
    pointBackgroundColor: "#fae206",
    pointBorderColor: "#fff",
    pointBorderWidth: 1,
  },
  {
    label: "Total de Consultas de Concluídos",
    data: [],
    borderColor: "#16a34a",
    backgroundColor: "rgba(22, 163, 74, 0.12)",
    fill: true,
    tension: 0.3,
    borderWidth: 5,
    pointRadius: 10,
    pointBackgroundColor: "#16a34a",
    pointBorderColor: "#fff",
    pointBorderWidth: 1,
  }
];

const pieConfig = {
  labels: ["concluidas",  "Agendadas"],
  backgroundColor: ["#16a34a", "#ffc107"],
  borderWidth: 2,
  borderColor: "#fff",
  hoverBorderWidth: 4,
};

const barConfig = {
  label: ["Concluídas por funcionário",],
  data: [],
  backgroundColor: "#03bd1cff",
  borderColor: "#03bd1cff",
  borderWidth: 2,
 
};

/* ===================================
   INICIALIZAÇÃO DOS GRÁFICOS
   =================================== */
function initCharts() {
  // === LINHA ===
  const lineCtx = document.getElementById("lineChart").getContext("2d");
  lineChart = new Chart(lineCtx, {
    type: "line",
    data: { labels: [], datasets: lineConfig }
  });

  // === PIZZA ===
  const pieCtx = document.getElementById("pieChart").getContext("2d");
  pieChart = new Chart(pieCtx, {
    type: "pie",
    data: {
      labels: pieConfig.labels,
      datasets: [{
        data: [0, 0],
        backgroundColor: pieConfig.backgroundColor,
        borderWidth: pieConfig.borderWidth,
        borderColor: pieConfig.borderColor,
        hoverBorderWidth: pieConfig.hoverBorderWidth,
        hoverBorderColor: pieConfig.hoverBorderColor
      }]
    },
    options: { responsive: true }
  });

  // === BARRAS ===
  const barCtx = document.getElementById("barChart").getContext("2d");
  barChart = new Chart(barCtx, {
    type: "bar",
    data: {
      labels: [],
      datasets: [barConfig]
    },
    options: { responsive: true, scales: { y: { beginAtZero: true } } }
  });
}

/* ===================================
   ATUALIZA O DASHBOARD NO PAINEL
   =================================== */
async function updateDashboard(dateFilter = null, aggregation = 'day') {
  try {
    const consultas = await fetchConsultasData();
    const concluidas = await fetchConcluidasData();
    const medicos = await fetchMedicosData();

    // Filtrar por data apenas para métricas e pizza (não altera linha e barras)
    let consultasFiltradas = consultas;
    let concluidasFiltradas = concluidas;
    if (dateFilter) {
      // Normalize filter date to YYYY-MM-DD
      const filterDateObj = new Date(dateFilter);
      const filterYear = filterDateObj.getFullYear();
      const filterMonth = filterDateObj.getMonth();
      const filterDay = filterDateObj.getDate();

      consultasFiltradas = consultas.filter(c => {
        const consultaDateObj = new Date(c.data);
        const consultaYear = consultaDateObj.getFullYear();
        const consultaMonth = consultaDateObj.getMonth();
        const consultaDay = consultaDateObj.getDate();
        return consultaYear === filterYear && consultaMonth === filterMonth && consultaDay === filterDay;
      });

      concluidasFiltradas = concluidas.filter(c => {
        const concluidaDateObj = new Date(c.data);
        const concluidaYear = concluidaDateObj.getFullYear();
        const concluidaMonth = concluidaDateObj.getMonth();
        const concluidaDay = concluidaDateObj.getDate();
        return concluidaYear === filterYear && concluidaMonth === filterMonth && concluidaDay === filterDay;
      });
    }

    // Metrics (filtradas se dateFilter fornecido)
    const agendadas = consultasFiltradas.length; // Consultas ativas (agendadas) no filtro
    const concluidasCount = concluidasFiltradas.length;
    const totalConsultas = consultas.length + concluidas.length; // Total sempre geral
    const canceladas = 0; // Placeholder, ajustar se houver campo de status

    document.getElementById("total-consultas").textContent = totalConsultas;
    document.getElementById("medicos-disponiveis").textContent = medicos.length;
    document.getElementById("agendadas").textContent = agendadas;
    document.getElementById("concluidas-count").textContent = concluidasCount;

    // === PIZZA === (filtrada por data)
    pieChart.data.datasets[0].data = [concluidasCount, agendadas];
    pieChart.update();

    // === LINHA === (conta por dia, mês, ano ou horas conforme aggregation)
    const consultasPorAgg = {};
    const concluidasPorAgg = {};

    // Contar consultas ativas por aggregation (todas)
    consultas.forEach(c => {
      const key = getAggregationKey(c.data, c.horario, aggregation);
      consultasPorAgg[key] = (consultasPorAgg[key] || 0) + 1;
    });

    // Contar consultas concluídas por aggregation (todas)
    concluidas.forEach(c => {
      const key = getAggregationKey(c.data, c.horario, aggregation);
      concluidasPorAgg[key] = (concluidasPorAgg[key] || 0) + 1;
    });

    // Combinar keys únicos de ambas as APIs
    const allKeys = new Set([...Object.keys(consultasPorAgg), ...Object.keys(concluidasPorAgg)]);
    const sortedKeys = Array.from(allKeys).sort();

    // Formatar labels conforme aggregation
    const labels = sortedKeys.map(key => formatLabel(key, aggregation));

    // Para cada key, somar ativas + concluídas (dataset 0)
    const totalData = sortedKeys.map(key => (consultasPorAgg[key] || 0) + (concluidasPorAgg[key] || 0));

    // Para cada key, apenas concluídas (dataset 1)
    const concluidasData = sortedKeys.map(key => concluidasPorAgg[key] || 0);

    lineChart.data.labels = labels;
    lineChart.data.datasets[0].data = totalData;
    lineChart.data.datasets[1].data = concluidasData;
    lineChart.update();

    // === BARRAS === (sempre todas, não alterada pelo filtro)
    const concluidasPorMedico = {};
    concluidas.forEach(c => {
      const medico = c.medico;
      concluidasPorMedico[medico] = (concluidasPorMedico[medico] || 0) + 1;
    });
    barChart.data.labels = Object.keys(concluidasPorMedico);
    barChart.data.datasets[0].data = Object.values(concluidasPorMedico);
    barChart.update();

    document.getElementById("last-updated").textContent = new Date().toLocaleString();

  } catch (err) {
    console.error("Erro dashboard:", err);
    alert("Erro ao atualizar dados.");
  }
}

/* ============================
        PDF COM jsPDF
   ============================ */
async function generatePDF() {
  const btn = document.getElementById("print-pdf-btn");
  btn.disabled = true;

  try {
    const area = document.getElementById("report-area");
    const canvas = await html2canvas(area, { scale: 2 });
    const img = canvas.toDataURL("image/png");

    const pdf = new jspdf.jsPDF("p", "pt", "a4");
    const w = pdf.internal.pageSize.getWidth();
    const h = canvas.height * (w / canvas.width);

    pdf.addImage(img, "PNG", 0, 10, w, h);
    pdf.save("relatorio-consultas.pdf");

  } catch (err) {
    console.error(err);
    alert("Erro ao gerar PDF");
  }

  btn.disabled = false;
}

/* ============================
        IMPRIMIR NAVEGADOR
   ============================ */
function printBrowser() {
  window.print();
}

/* ===============================
           START DO PAINEL
   =============================== */
document.addEventListener("DOMContentLoaded", async () => {
  initCharts();

  const dateInput = document.getElementById("date-filter");
  dateInput.value = new Date().toISOString().slice(0, 10);

  await updateDashboard();

  // Event listener para filtro de data (atualiza apenas pizza e métricas)
  dateInput.addEventListener("change", () => {
    updateDashboard(dateInput.value);
  });

  document.getElementById("refresh-btn")
    .addEventListener("click", () => updateDashboard());

  // Event listener para agregação (atualiza apenas linha)
  const aggregationSelect = document.getElementById("aggregation-select");
  aggregationSelect.addEventListener("change", () => {
    updateDashboard(dateInput.value, aggregationSelect.value);
  });

  document.getElementById("print-browser-btn")
    .addEventListener("click", printBrowser);

  document.getElementById("print-pdf-btn")
    .addEventListener("click", generatePDF);
});
