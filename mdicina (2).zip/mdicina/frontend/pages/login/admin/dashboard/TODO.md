# TODO: Corrigir problemas de conexão API e erros DOM no dashboard

## Passos a executar:

- [ ] Atualizar frontend/pages/login/admin/dashboard/dashboard.html
  - [ ] Adicionar tbody com id="tbody-relatorio" para a tabela do relatório de usuários.
  - [ ] Adicionar tbody com id="tbody-funcionarios" para a tabela de funcionários.

- [ ] Atualizar frontend/pages/login/admin/dashboard/dashboard.js
  - [ ] Atualizar carregarRelatorioUsuarios para buscar dados de "/api/reports/concluidas-por-funcionario?date=YYYY-MM-DD" passando data atual.
  - [ ] Ajustar renderização da tabela no carregarRelatorioUsuarios para usar campos do backend ('nome', 'concluidas').
  - [ ] Garantir que carregarFuncionarios utilize o id correto do tbody adicionado no HTML.
  - [ ] Adicionar verificações para evitar erros ao modificar elementos nulos.

- [ ] Testar as correções localmente para verificar se os erros 404 e innerHTML de null foram resolvidos.
