// script.js - Cadastro e listagem de médicos
document.addEventListener("DOMContentLoaded", async () => {
  const form = document.querySelector("form");
  const tabela = document.querySelector("tbody");

  function gerarCRM() {
    return Math.floor(100000 + Math.random() * 900000);
  }

  async function carregarMedicos() {
    try {
      const res = await fetch("http://localhost:3000/api/medicos");
      const medicos = await res.json();

      tabela.innerHTML = "";

      if (medicos.length === 0) {
        tabela.innerHTML = `<tr><td colspan="4" class="text-muted small">Nenhum médico cadastrado</td></tr>`;
        return;
      }

      medicos.forEach(medico => {
        tabela.innerHTML += `
          <tr>
            <td>${medico.nome}</td>
            <td>${medico.especialidade}</td>
            <td>${medico.crm}</td>
            <td>${medico.horario_atendimento || "-"}</td>
          </tr>
        `;
      });

    } catch (erro) {
      console.error("Erro ao carregar médicos:", erro);
      tabela.innerHTML = `<tr><td colspan="4" class="text-danger">Erro ao carregar médicos</td></tr>`;
    }
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const nome = form.nome.value.trim();
    const especialidade = form.especialidade.value.trim();

    const inicio = document.getElementById("hora-inicio").value;
    const fim = document.getElementById("hora-fim").value;

    if (!inicio || !fim) {
      alert("Selecione o horário de início e fim.");
      return;
    }

    const horario_atendimento = `${inicio} - ${fim}`;

    const crm = gerarCRM();

    try {
      const res = await fetch("http://localhost:3000/api/medicos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, especialidade, crm, horario_atendimento })
      });

      const resultado = await res.json();

      if (res.ok) {
        alert(`✅ Médico cadastrado com sucesso! CRM: ${crm}`);
        form.reset();
        carregarMedicos();
      } else {
        alert(`⚠️ Erro: ${resultado.error || "Falha ao cadastrar médico."}`);
      }

    } catch (erro) {
      console.error("Erro ao cadastrar médico:", erro);
      alert("❌ Falha na comunicação com o servidor.");
    }
  });

  carregarMedicos();
});
