let todasConsultas = []; // Armazenar todas as consultas para filtragem
let consultasConcluidas = []; // Armazenar consultas concluídas

// Modal de exclusão
const modalExcluirEl = document.getElementById("modalExcluir");
const modalExcluir = new bootstrap.Modal(modalExcluirEl);
const btnConfirmarExcluir = document.getElementById("btnConfirmarExcluir");
let idParaExcluir = null;

btnConfirmarExcluir.addEventListener("click", async () => {
  if (!idParaExcluir) return;
  await excluirConsulta(idParaExcluir);
  modalExcluir.hide();
  idParaExcluir = null;
});

// Modal de conclusão
const modalConcluirEl = document.getElementById("modalConcluir");
const modalConcluir = new bootstrap.Modal(modalConcluirEl);
const btnConfirmarConcluir = document.getElementById("btnConfirmarConcluir");
let idParaConcluir = null;

btnConfirmarConcluir.addEventListener("click", async () => {
  if (!idParaConcluir) return;
  await concluirConsulta(idParaConcluir);
  modalConcluir.hide();
  idParaConcluir = null;
});

async function carregarConsultas() {
  try {
    const res = await fetch("http://localhost:3000/api/consultas");
    if (!res.ok) throw new Error("Erro ao carregar consultas");

    todasConsultas = await res.json();
    console.log(todasConsultas);

    renderizarConsultas(todasConsultas, '');
    await carregarConcluidas();

  } catch (err) {
    console.error("Erro ao carregar consultas:", err);
    alert("Erro ao carregar lista de consultas");
  }
}

async function carregarConcluidas() {
  try {
    const res = await fetch("http://localhost:3000/api/concluida");
    if (!res.ok) throw new Error("Erro ao carregar consultas concluídas");

    consultasConcluidas = await res.json();
    renderizarConcluidas(consultasConcluidas);

  } catch (err) {
    console.error("Erro ao carregar consultas concluídas:", err);
  }
}

function renderizarConsultas(consultas, termoBusca = '') {
  const tbody = document.querySelector('tbody');
  if (tbody) {
    tbody.innerHTML = consultas.map(c => {
      const medicoMatch = c.medico.toLowerCase().includes(termoBusca);
      const crmMatch = c.crm_medico && c.crm_medico.toString().includes(termoBusca);
      const isHighlighted = termoBusca && (medicoMatch || crmMatch);

      return `
        <tr class="${isHighlighted ? 'table-warning' : ''}">
          <td>${c.paciente}</td>
          <td>${isHighlighted && medicoMatch ? `<span class="text-primary">${c.medico}</span>` : c.medico}</td>
          <td>${isHighlighted && crmMatch ? `<span class="text-primary">${c.crm_medico || ''}</span>` : (c.crm_medico || '')}</td>
          <td>${new Date(c.data).toLocaleDateString("pt-BR")}</td>
          <td>${c.horario}</td>
          <td>
            <button class="btn btn-outline-success btn-sm" onclick="abrirModalConcluir(${c.id})">Concluido</button>
            <button class="btn btn-outline-danger btn-sm" onclick="abrirModalExcluir(${c.id})">Cancelar</button>
          </td>
        </tr>
      `;
    }).join("");
  }
}

function renderizarConcluidas(concluidas) {
  const tbody = document.getElementById('tbodyConcluidos');
  if (tbody) {
    tbody.innerHTML = concluidas.length ? concluidas.map(c => `
      <tr>
        <td>${c.paciente}</td>
        <td>${c.medico}</td>
        <td>${c.crm_medico || ''}</td>
        <td>${new Date(c.data).toLocaleDateString("pt-BR")}</td>
        <td>${c.horario}</td>
      </tr>
    `).join("") : '<tr><td colspan="5" class="small-muted">Nenhuma consulta concluída</td></tr>';
  }
}

async function concluirConsulta(id) {
  try {
    // Marcar consulta como concluída
    const res = await fetch("http://localhost:3000/api/concluida", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ consulta_id: id })
    });

    if (!res.ok) {
      alert("Erro ao marcar consulta como concluída.");
      return;
    }

    // Atualizar interface
    todasConsultas = todasConsultas.filter(c => c.id !== id);
    renderizarConsultas(todasConsultas, '');
    await carregarConcluidas();
    alert("Consulta marcada como concluída.");
    await carregarConsultas(); // Atualizar dados após conclusão

  } catch (err) {
    console.error("Erro ao concluir consulta:", err);
    alert("Erro ao marcar consulta como concluída.");
  }
}

function abrirModalExcluir(id) {
  idParaExcluir = id;
  modalExcluir.show();
}

function abrirModalConcluir(id) {
  idParaConcluir = id;
  modalConcluir.show();
}

async function excluirConsulta(id) {
  if (confirm("Tem certeza que deseja cancelar e excluir definitivamente esta consulta?")) {
    try {
      const res = await fetch(`http://localhost:3000/api/consultas/${id}`, {
        method: "DELETE"
      });
      if (res.ok) {
        // Remover da lista ativa
        todasConsultas = todasConsultas.filter(c => c.id !== id);
        renderizarConsultas(todasConsultas, '');
        alert("Consulta excluída com sucesso.");
      } else {
        alert("Erro ao excluir consulta.");
      }
    } catch (err) {
      console.error("Erro ao excluir consulta:", err);
      alert("Erro ao excluir consulta.");
    }
  }
}

function filtrarConsultas() {
  const termo = document.getElementById('searchMedico').value.toLowerCase();
  const filtradas = todasConsultas.filter(c =>
    c.medico.toLowerCase().includes(termo) ||
    (c.crm_medico && c.crm_medico.toString().includes(termo))
  );
  renderizarConsultas(filtradas, termo);
}

// Chama ao carregar página:
carregarConsultas();
