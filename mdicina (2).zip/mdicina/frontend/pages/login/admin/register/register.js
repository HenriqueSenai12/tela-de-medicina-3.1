document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("form");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    // --- Pegando todos os campos do formulário ---
    const nome = form.nome?.value?.trim();
    const email = form.email?.value?.trim();
    const senha = form.senha?.value?.trim();
    const tipo = form.tipo?.value?.trim();

    // Validação simples
    if (!nome || !email || !senha || !tipo) {
      alert("Por favor, preencha todos os campos!");
      return;
    }

    try {
      // Envia dados para o backend (certifique-se de que a rota espera esses campos)
      const response = await fetch("http://localhost:3000/api/users/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, email, senha, tipo }),
      });

      const data = await response.json();

      if (response.ok) {
        // Mensagem de sucesso adequada para registro
        alert(`✅ Registro realizado com sucesso! Bem-vindo(a), ${data.user?.nome || nome}`);

        // Armazena informações do usuário (exemplo simples)
        if (data.user) localStorage.setItem("usuario", JSON.stringify(data.user));

        // Normaliza o tipo retornado pelo servidor (remove acentos e compara em lowercase)
        const tipoServidor = (data.user?.tipo || tipo || "")
          .normalize ? (data.user?.tipo || tipo).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase()
          : (data.user?.tipo || tipo).toLowerCase();

        // Redirecionamentos por tipo
        if (tipoServidor === "admin") {
          window.location.href = "admin/dashboard/dashboard.html";

        } else if (tipoServidor === "medico") {
          // Novo redirecionamento para médicos
          window.location.href = "medico/dashboard/dashboard.html";
        }  else if (tipoServidor === "recepcao") {
          // padrão para recepção e outros tipos
          // Use "recepcao" sem acento para evitar problemas de URL; ajuste se sua pasta realmente tiver acento
          window.location.href = "recepcao/recepcao.html";
        }
      } else {
        // Mostra erro retornado pelo servidor (se houver)
        alert(`⚠️ Erro: ${data.error || "Registro falhou"}`);
      }
    } catch (err) {
      console.error("Erro ao registrar:", err);
      alert("❌ Erro de conexão com o servidor.");
    }
  });
});