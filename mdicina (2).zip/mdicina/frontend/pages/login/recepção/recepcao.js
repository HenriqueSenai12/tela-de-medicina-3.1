// =======================================================================
// DASHBOARD RECEPÇÃO – LISTAGEM, EDIÇÃO, EXCLUSÃO E CONCLUSÃO DE CONSULTAS
// =======================================================================

let todasConsultas = []; // Armazenar todas as consultas para filtragem
let consultasConcluidas = []; // Armazenar consultas concluídas

// ========================== FILTRAR CONSULTAS ==========================

function filtrarConsultas() {
  const termo = document.getElementById('searchMedico').value.toLowerCase();
  const filtradas = todasConsultas.filter(c =>
    c.medico.toLowerCase().includes(termo) ||
    (c.crm_medico && c.crm_medico.toString().includes(termo))
  );
  renderTabela(filtradas, termo);
}

document.addEventListener("DOMContentLoaded", async () => {

  // ---------------------------
  // ELEMENTOS DA INTERFACE
  // ---------------------------
  const tabelaBody = document.querySelector("tbody");
  const totalConsultasEl = document.querySelector("#total_consultas");
  const totalPacientesEl = document.querySelector("#total_pacientes");
  const listaMedicosEl = document.querySelector(".bg-3 ul");
  const saudacaoEl = document.querySelector("p strong");
  const dataHojeEl = document.querySelector("small");

  // ---------------------------
  // MODAL EDITAR CONSULTA
  // ---------------------------
  const editarModal = new bootstrap.Modal(document.getElementById("editarModal"));
  const formEditar = document.getElementById("formEditar");
  const inputConsultaId = document.getElementById("editarConsultaId");
  const selectPaciente = document.getElementById("editarPaciente");
  const selectMedico = document.getElementById("editarMedico");
  const inputData = document.getElementById("editarData");
  const inputHorario = document.getElementById("editarHorario");
  const editarFeedback = document.getElementById("editarFeedback");

  // ---------------------------
  // MODAL EXCLUIR CONSULTA
  // ---------------------------
  const modalExcluir = new bootstrap.Modal(document.getElementById("modalExcluir"));
  let idParaExcluir = null;

  document.getElementById("btnConfirmarExcluir").addEventListener("click", async () => {
    if (!idParaExcluir) return;
    await excluirConsulta(idParaExcluir);
    modalExcluir.hide();
    idParaExcluir = null;
  });

  // ---------------------------
  // MODAL CONCLUIR CONSULTA
  // ---------------------------
  const modalConcluir = new bootstrap.Modal(document.getElementById("modalConcluir"));
  let idParaConcluir = null;

  document.getElementById("btnConfirmarConcluir").addEventListener("click", async () => {
    if (!idParaConcluir) return;
    await concluirConsulta(idParaConcluir);
    modalConcluir.hide();
    idParaConcluir = null;
  });



  // ---------------------------
  // LOGIN – PEGAR USUÁRIO
  // ---------------------------
  function getUsuarioLogado() {
    return (
      JSON.parse(localStorage.getItem("user")) ||
      JSON.parse(localStorage.getItem("usuario")) ||
      JSON.parse(localStorage.getItem("admin"))
    );
  }

  const user = getUsuarioLogado();
  if (!user) {
    alert("⚠️ Faça login para acessar o sistema.");
    window.location.href = "../login/views_login.html";
    return;
  }

  saudacaoEl.textContent = user.nome;
  dataHojeEl.textContent = new Date().toLocaleDateString("pt-BR");

  // Adicionar event listener para o filtro
  document.getElementById('searchMedico').addEventListener('input', filtrarConsultas);

  // ========================== FUNÇÕES DE BACKEND ====================================

  async function fetchPacientes() {
    const res = await fetch("http://localhost:3000/api/pacientes");
    return res.json();
  }

  async function fetchMedicos() {
    const res = await fetch("http://localhost:3000/api/medicos");
    return res.json();
  }


  // ========================== CARREGAR DASHBOARD ====================================

  async function carregarDashboard() {
    try {
      const consultasRes = await fetch("http://localhost:3000/api/consultas");
      todasConsultas = await consultasRes.json();

      const pacientes = await fetchPacientes();
      const medicos = await fetchMedicos();

      totalPacientesEl.textContent = pacientes.length;

      const hojeISO = new Date().toISOString().split("T")[0];
      const consultasHoje = todasConsultas.filter(c => c.data.startsWith(hojeISO));
      totalConsultasEl.textContent = consultasHoje.length;

      // Médicos → lista lateral
      const medicosMap = {};
      todasConsultas.forEach(c => {
        if (!medicosMap[c.medico]) {
          medicosMap[c.medico] = { especialidade: c.especialidade, total: 0 };
        }
        medicosMap[c.medico].total++;
      });

      listaMedicosEl.innerHTML = Object.keys(medicosMap).length
        ? Object.entries(medicosMap)
            .map(([nome, info]) => `<li><strong>${nome}</strong> (${info.especialidade}) — ${info.total} consultas</li>`)
            .join("")
        : `<li class="small-muted">Nenhum dado</li>`;

      renderTabela(todasConsultas, '');
      await carregarConcluidas();

    } catch (err) {
      console.error(err);
      alert("Erro ao carregar dashboard");
    }
  }


  // ========================== CARREGAR CONCLUÍDAS ====================================

  async function carregarConcluidas() {
    try {
      const res = await fetch("http://localhost:3000/api/concluida");
      if (!res.ok) throw new Error("Erro ao carregar consultas concluídas");

      consultasConcluidas = await res.json();
      renderizarConcluidas(consultasConcluidas);

    } catch (err) {
      console.error("Erro ao carregar consultas concluídas:", err);
    }
  }

  // ========================== RENDERIZAR TABELA ====================================

  function renderTabela(consultas, termoBusca = '') {
    tabelaBody.innerHTML = "";

    if (!consultas.length) {
      tabelaBody.innerHTML = `<tr><td colspan="6" class="small-muted">Nenhum agendamento encontrado</td></tr>`;
      return;
    }

    consultas.forEach(c => {
      const medicoMatch = c.medico.toLowerCase().includes(termoBusca);
      const crmMatch = c.crm_medico && c.crm_medico.toString().includes(termoBusca);
      const isHighlighted = termoBusca && (medicoMatch || crmMatch);

      tabelaBody.innerHTML += `
        <tr data-id="${c.id}" class="${isHighlighted ? 'table-warning' : ''}">
          <td>${c.paciente}</td>
          <td>${isHighlighted && medicoMatch ? `<span class="text-primary">${c.medico}</span>` : c.medico}</td>
          <td>${isHighlighted && crmMatch ? `<span class="text-primary">${c.crm_medico || ''}</span>` : (c.crm_medico || '')}</td>
          <td>${new Date(c.data).toLocaleDateString("pt-BR")}</td>
          <td>${c.horario}</td>
          <td>
            <div class="d-flex gap-2">
              <button class="btn btn-sm btn-outline-primary btn-editar" data-id="${c.id}">
                <i class="bi bi-pencil-square"></i> Editar
              </button>
              <button class="btn btn-sm btn-outline-success btn-concluir" data-id="${c.id}">
                <i class="bi bi-check-circle"></i> Concluído
              </button>
              <button class="btn btn-sm btn-outline-danger btn-cancel" data-id="${c.id}">
                <i class="bi bi-x-circle"></i> Excluir
              </button>
            </div>
          </td>
        </tr>
      `;
    });

    document.querySelectorAll(".btn-cancel").forEach(btn =>
      btn.addEventListener("click", () => {
        idParaExcluir = btn.dataset.id;
        modalExcluir.show();
      })
    );



    document.querySelectorAll(".btn-editar").forEach(btn =>
      btn.addEventListener("click", () => abrirModalEditar(btn.dataset.id))
    );

    document.querySelectorAll(".btn-concluir").forEach(btn =>
      btn.addEventListener("click", () => {
        idParaConcluir = btn.dataset.id;
        modalConcluir.show();
      })
    );
  }

  // ========================== RENDERIZAR CONCLUÍDAS ====================================

  function renderizarConcluidas(concluidas) {
    const tbody = document.getElementById('tbodyConcluidos');
    if (tbody) {
      tbody.innerHTML = concluidas.length ? concluidas.map(c => `
        <tr>
          <td>${c.paciente}</td>
          <td>${c.medico}</td>
          <td>${c.crm_medico || ''}</td>
          <td>${new Date(c.data).toLocaleDateString("pt-BR")}</td>
          <td>${c.horario}</td>
        </tr>
      `).join("") : '<tr><td colspan="5" class="small-muted">Nenhuma consulta concluída</td></tr>';
    }
  }


  // ========================== EXCLUIR CONSULTA ====================================

  async function excluirConsulta(id) {
    try {
      const res = await fetch(`http://localhost:3000/api/consultas/${id}`, { method: "DELETE" });
      if (!res.ok) return alert("Erro ao excluir");
      await carregarDashboard();
    } catch (e) {
      alert("Erro ao excluir consulta");
    }
  }

  // ========================== CONCLUIR CONSULTA ====================================

  async function concluirConsulta(id) {
    try {
      // Marcar consulta como concluída
      const res = await fetch("http://localhost:3000/api/concluida", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ consulta_id: id })
      });

      if (!res.ok) {
        alert("Erro ao marcar consulta como concluída.");
        return;
      }

      // Atualizar interface
      todasConsultas = todasConsultas.filter(c => c.id !== id);
      renderTabela(todasConsultas, '');
      await carregarConcluidas();
      alert("Consulta marcada como concluída.");
      await carregarDashboard(); // Atualizar dados após conclusão

    } catch (err) {
      console.error("Erro ao concluir consulta:", err);
      alert("Erro ao marcar consulta como concluída.");
    }
  }





  // ========================== EDITAR CONSULTA ====================================

  async function abrirModalEditar(id) {
    try {
      const pacientes = await fetchPacientes();
      const medicos = await fetchMedicos();

      selectPaciente.innerHTML = pacientes.map(p => `<option value="${p.id}">${p.nome}</option>`).join("");
      selectMedico.innerHTML = medicos.map(m => `<option value="${m.id}">${m.nome} (${m.especialidade})</option>`).join("");

      const res = await fetch(`http://localhost:3000/api/consultas/${id}`);
      const c = await res.json();

      inputConsultaId.value = c.id;
      inputData.value = c.data.split("T")[0];
      inputHorario.value = c.horario.slice(0, 5);
      selectPaciente.value = c.paciente_id;
      selectMedico.value = c.medico_id;

      editarModal.show();

    } catch (err) {
      alert("Erro ao carregar dados da consulta");
    }
  }


  formEditar.addEventListener("submit", async e => {
    e.preventDefault();

    const id = inputConsultaId.value;
    const body = JSON.stringify({
      paciente_id: selectPaciente.value,
      medico_id: selectMedico.value,
      data: inputData.value,
      horario: inputHorario.value + ":00"
    });

    const res = await fetch(`http://localhost:3000/api/consultas/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body
    });

    if (!res.ok) return alert("Erro ao atualizar");

    editarModal.hide();
    alert("Consulta atualizada!");
    await carregarDashboard();
  });


  // ========================== FILTRAR CONSULTAS ==========================

  function filtrarConsultas() {
    const termo = document.getElementById('searchMedico').value.toLowerCase();
    const filtradas = todasConsultas.filter(c =>
      c.medico.toLowerCase().includes(termo) ||
      (c.crm_medico && c.crm_medico.toString().includes(termo))
    );
    renderTabela(filtradas, termo);
  }

  // ========================== INICIAR ==========================
  await carregarDashboard();
});
