-- =========================================================
--  SCHEMA: Sistema de Agendamento Médico
-- =========================================================

CREATE DATABASE IF NOT EXISTS agenda_medica 
  CHARACTER SET utf8mb4 
  COLLATE utf8mb4_unicode_ci;

USE agenda_medica;

-- =========================================================
--  Tabela: Usuários do Sistema
-- =========================================================

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  senha VARCHAR(255) NOT NULL,
  tipo ENUM('admin','recepcao','medico') DEFAULT 'recepcao',
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================================================
--  Tabela: Pacientes
-- =========================================================

CREATE TABLE IF NOT EXISTS pacientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(150) NOT NULL,
  cpf VARCHAR(20) UNIQUE,
  telefone VARCHAR(50),
  data_nascimento DATE,
  endereco VARCHAR(255),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================================================
--  Tabela: Médicos
-- =========================================================

CREATE TABLE IF NOT EXISTS medicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(150) NOT NULL UNIQUE,
  nome VARCHAR(150) NOT NULL,
  especialidade VARCHAR(100),
  crm VARCHAR(50) UNIQUE,
  cpf VARCHAR(20) UNIQUE,
  horario_atendimento VARCHAR(255),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================================================
--  Tabela: Consultas
-- =========================================================

CREATE TABLE IF NOT EXISTS consultas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  paciente_id INT NOT NULL,
  medico_id INT NOT NULL,
  data DATE NOT NULL,
  horario TIME NOT NULL,
  status ENUM('agendada', 'concluida') DEFAULT 'agendada',
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (paciente_id) REFERENCES pacientes(id) ON DELETE CASCADE,
  FOREIGN KEY (medico_id) REFERENCES medicos(id) ON DELETE CASCADE,

  UNIQUE KEY unico_medico_paciente_data_hora (medico_id, paciente_id, data, horario)
);

-- =========================================================
--  Adicionar coluna status SE NÃO EXISTIR (MySQL compatível)
-- =========================================================

SET @coluna_existe := (
    SELECT COUNT(*)
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = 'agenda_medica'
      AND TABLE_NAME   = 'consultas'
      AND COLUMN_NAME  = 'status'
);

SET @sql := IF(
    @coluna_existe = 0,
    'ALTER TABLE consultas ADD COLUMN status ENUM(''agendada'', ''concluida'') DEFAULT ''agendada'';',
    'SELECT "Coluna status já existe";'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Garantir que valores NULL sejam corrigidos
UPDATE consultas 
SET status = 'agendada'
WHERE status IS NULL;

-- =========================================================
--  Seed de Exemplo
-- =========================================================

INSERT IGNORE INTO users (nome, email, senha, tipo)
VALUES (
  'Administrador',
  'admin@example.com',
  '$2b$10$placeholder_for_hashed_password',
  'admin'
);

-- =========================================================
--  Tabela: Estatísticas de Consultas Concluídas
-- =========================================================

CREATE TABLE IF NOT EXISTS consultas_concluidas_stats (
  id INT AUTO_INCREMENT PRIMARY KEY,
  data DATE NOT NULL,
  total_concluidas INT DEFAULT 0,
  UNIQUE KEY unico_data (data)
);

-- =========================================================
--  Consultas úteis
-- =========================================================

SELECT * FROM consultas;
SELECT * FROM medicos;
SELECT * FROM users;
