const express = require('express');
const router = express.Router();
const pool = require('../db');

// Registrar consulta como concluída
router.post('/', async (req, res) => {
  try {
    const { consulta_id } = req.body;
    if (!consulta_id)
      return res.status(400).json({ error: "consulta_id obrigatório" });

    // Verificar se consulta existe e está agendada
    const [verifica] = await pool.query(
      "SELECT id FROM consultas WHERE id = ? AND status = 'agendada'",
      [consulta_id]
    );
    if (verifica.length === 0)
      return res.status(404).json({ error: "Consulta não encontrada ou já concluída" });

    // Atualizar status para concluída
    const [result] = await pool.query(
      "UPDATE consultas SET status = 'concluida' WHERE id = ?",
      [consulta_id]
    );

    return res.status(200).json({
      message: "Consulta marcada como concluída",
    });

  } catch (err) {
    console.error("Erro ao registrar concluída:", err);
    return res.status(500).json({ error: "Erro interno no servidor" });
  }
});

// Listar consultas concluídas (JOIN COMPLETO)
router.get('/', async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT
          cons.id,
          cons.criado_em AS concluido_em,
          cons.data,
          cons.horario,
          p.nome AS paciente,
          m.nome AS medico,
          m.crm AS crm_medico
       FROM consultas cons
       JOIN pacientes p ON cons.paciente_id = p.id
       JOIN medicos m   ON cons.medico_id   = m.id
       WHERE cons.status = 'concluida'
       ORDER BY cons.criado_em DESC`
    );

    res.json(rows);

  } catch (err) {
    console.error("Erro ao listar concluídas:", err);
    return res.status(500).json({ error: "Erro interno ao listar concluídas" });
  }
});

module.exports = router;
