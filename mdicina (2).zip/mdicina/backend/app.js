const express = require('express');
const cors = require('cors');
require('dotenv').config();
const path = require('path');
const cron = require('node-cron');

// Rotas da API
const usersRouter = require('./routes/users');
const pacientesRouter = require('./routes/pacientes');
const medicosRouter = require('./routes/medicos');
const consultasRouter = require('./routes/consultas');
const concluidaRouter = require('./routes/concluida');
const reportsRouter = require('./routes/reports');

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Permitir servir arquivos estáticos do frontend
app.use(express.static(path.join(__dirname, "frontend")));

// Rotas da API
app.use('/api/users', usersRouter);
app.use('/api/pacientes', pacientesRouter);
app.use('/api/medicos', medicosRouter);
app.use('/api/consultas', consultasRouter);
app.use('/api/concluida', concluidaRouter);
app.use('/api/reports', reportsRouter);

// Rota raiz
app.get('/', (req, res) => {
    res.send('API Agenda Médica - OK');
});

// Cron job para limpeza automática de consultas concluídas (a cada hora)
cron.schedule('0 * * * *', async () => {
    console.log('Executando limpeza automática de consultas concluídas...');

    try {
        const db = require('./db');

        // 1. Buscar consultas concluídas com mais de 24 horas
        const [rows] = await db.execute(`
            SELECT id, DATE(criado_em) as data_conclusao
            FROM concluida
            WHERE criado_em < DATE_SUB(NOW(), INTERVAL 24 HOUR)
        `);

        if (rows.length > 0) {
            // 2. Atualizar estatísticas antes de deletar
            for (const row of rows) {
                const data = row.data_conclusao;
                await db.execute(`
                    INSERT INTO consultas_concluidas_stats (data, total_concluidas)
                    VALUES (?, 1)
                    ON DUPLICATE KEY UPDATE total_concluidas = total_concluidas + 1
                `, [data]);
            }

            // 3. Deletar registros antigos
            const ids = rows.map(row => row.id);
            await db.execute(`DELETE FROM concluida WHERE id IN (${ids.join(',')})`);

            console.log(`${rows.length} consultas concluídas removidas e estatísticas atualizadas.`);
        }

    } catch (error) {
        console.error('Erro na limpeza automática:', error);
    }
});

// Iniciar servidor
const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
